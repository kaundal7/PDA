import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.util.Scanner;
import javax.swing.border.Border;
public class PDA extends JFrame {
	
	WindowListener wl = new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
            System.exit(0);
        }
    };
    Scanner sc = new Scanner(System.in);
	 String url;
	 Document document;
	 Element p;
	PDA() throws Exception
	{
		JLabel L_head;
		getContentPane().setBackground(Color.WHITE);
		L_head = new JLabel();
		L_head.setBounds(300, 50, 600, 100);
		ImageIcon iconLogo = new ImageIcon("man.png");
		L_head.setIcon(iconLogo);
		add(L_head);
		Font myFont = new Font("Tempus Sans ITC",Font.BOLD,20);
        L_head.setFont(myFont);
        JButton b=new JButton(new ImageIcon("news.png"));    
        b.setBounds(110,200,130, 130);    
        b.setBackground(Color.WHITE);
        b.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        add(b); 
        JButton b_1=new JButton(new ImageIcon("Weather.png"));    
        b_1.setBounds(270,200,130, 130);    
        b_1.setBackground(Color.WHITE);
        b_1.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        add(b_1);
        
        
        
        JButton b_2=new JButton(new ImageIcon("currency.png"));    
        b_2.setBounds(430,200,130, 130);    
        b_2.setBackground(Color.WHITE);
        b_2.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        add(b_2);
        
        JButton b_3=new JButton(new ImageIcon("dict.png"));    
        b_3.setBounds(590,200,130, 130);    
        b_3.setBackground(Color.WHITE);
        b_3.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        add(b_3);
        
        JButton b_4=new JButton(new ImageIcon("find.png"));    
        b_4.setBounds(750,200,130, 130);    
        b_4.setBackground(Color.WHITE);
        b_4.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        add(b_4);
		setSize(1000,500);
		addWindowListener(wl);
		
		b_4.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent event) {
		        setVisible(false);
		        JFrame fi = new JFrame();
				fi.setLayout(null);
				fi.setVisible(true);
				JLabel S_head;
				S_head = new JLabel("SHORT INFO");
				S_head.setBounds(440, 75, 150, 50);
				fi.add(S_head);
				Font myFont = new Font("High Tower Text",Font.BOLD,20);
		        S_head.setFont(myFont);
		        JTextField tf1;
		        tf1=new JTextField();
		        tf1.setBounds(320,150,200,20);  
		        fi.add(tf1);
		        ImageIcon imageIcon = new ImageIcon("back.png");
				Image image = imageIcon.getImage();
				Image newimg = image.getScaledInstance(50, 50,  java.awt.Image.SCALE_SMOOTH);
				imageIcon = new ImageIcon(newimg);
		        JButton b_5=new JButton(imageIcon);
		        b_5.setBounds(30,50,100, 100);    
		        b_5.setBackground(Color.WHITE);
		        b_5.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_5);
		        
		        
				ImageIcon imageIcon_2 = new ImageIcon("search.png");
				Image images = imageIcon_2.getImage();
				Image newimgs = images.getScaledInstance(130, 25,  java.awt.Image.SCALE_SMOOTH);
				imageIcon_2 = new ImageIcon(newimgs);
		        JButton b_6=new JButton(imageIcon_2);
		        b_6.setBounds(530, 123,200, 70);    
		        b_6.setBackground(Color.WHITE);
		        b_6.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_6);
				
		        b_6.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				    		JLabel info = new JLabel();
							info = new JLabel("");
							info.setBounds(280, 210,450,150);
							fi.add(info);
				    		info.setText(" ");
				    		String S = tf1.getText();
				    		S = S.replace(" ", "_");
						 	String url_1 = "https://en.wikipedia.org/wiki/"+S;
						 	try {
								document = Jsoup.connect(url_1).get();
							} catch (IOException e) {
								e.printStackTrace();
							}	
						 	Elements paragraphs = document.select(".mw-content-ltr p");
						 	Element firstParagraph = paragraphs.first();
							Element p=firstParagraph;
							String news = " ";
					        news="<html>"+p.text()+"</html>";
					        info.setText(news);

				    }
				});
		        
				fi.setSize(1000,500);
				fi.addWindowListener(wl);
				fi.setResizable(false);
				
				b_5.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				        setVisible(true);
				        fi.setVisible(false);
				    }
				});
		    }
		});
		
		b_3.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent event) {
		        setVisible(false);
		        JFrame fi = new JFrame();
				fi.setLayout(null);
				fi.setVisible(true);
				JLabel S_head;
				S_head = new JLabel("DICTIONARY");
				S_head.setBounds(440, 75, 150, 50);
				fi.add(S_head);
				Font myFont = new Font("High Tower Text",Font.BOLD,20);
		        S_head.setFont(myFont);
		        JLabel info = new JLabel();
				info = new JLabel("");
			    info.setBounds(320, 210,450,30);
				fi.add(info);
		        JTextField tf1;
		        tf1=new JTextField();
		        tf1.setBounds(320,150,200,20);  
		        fi.add(tf1);
		        ImageIcon imageIcon = new ImageIcon("back.png");
				Image image = imageIcon.getImage();
				Image newimg = image.getScaledInstance(50, 50,  java.awt.Image.SCALE_SMOOTH);
				imageIcon = new ImageIcon(newimg);
		        JButton b_5=new JButton(imageIcon);
		        b_5.setBounds(30,50,100, 100);    
		        b_5.setBackground(Color.WHITE);
		        b_5.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_5);
		        
		        
				ImageIcon imageIcon_2 = new ImageIcon("search.png");
				Image images = imageIcon_2.getImage();
				Image newimgs = images.getScaledInstance(130, 25,  java.awt.Image.SCALE_SMOOTH);
				imageIcon_2 = new ImageIcon(newimgs);
		        JButton b_6=new JButton(imageIcon_2);
		        b_6.setBounds(530, 123,200, 70);    
		        b_6.setBackground(Color.WHITE);
		        b_6.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_6);
				
		        b_6.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				    	JLabel info = new JLabel();
						info = new JLabel("");
						info.setBounds(200, 210,650,150);
						fi.add(info);
						
						String word = tf1.getText();
					 	url = "https://en.oxforddictionaries.com/definition/"+word;
					 	try {
							document = Jsoup.connect(url).get();
						} catch (IOException e) {
							e.printStackTrace();
						}
					 	
					 	Elements d_info = document.select(".ind");
					 	Element firstParagraph_d = d_info.first();
					    p=firstParagraph_d;
					    String w = "<html>Meaning: " +p.text()+"</html>";
						Font myFont = new Font("High Tower Text",Font.BOLD,30);
				        info.setFont(myFont);
					    info.setText(w);
			    	
				    }
				});
		        
				fi.setSize(1000,500);
				fi.addWindowListener(wl);
				fi.setResizable(false);
				
				b_5.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				        setVisible(true);
				        fi.setVisible(false);
				    }
				});
		    }
		});
		
		b_2.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent event) {
		        setVisible(false);
		        JFrame fi = new JFrame();
		        fi.getContentPane().setBackground(Color.WHITE);
				fi.setLayout(null);
				fi.setVisible(true);
				Font myFont = new Font("High Tower Text",Font.BOLD,15);
				
				JLabel from;
				from = new JLabel("From : ");
				from.setBounds(200, 130, 350, 50);
				fi.add(from);
				
		        from.setFont(myFont);
		        
		        JLabel to;
				to = new JLabel("To : ");
				to.setBounds(530, 130, 350, 50);
				fi.add(to);
		        to.setFont(myFont);
		        
		        JLabel S_head;
				S_head = new JLabel("Currency Converter");
				S_head.setBounds(370, 75, 350, 50);
				fi.add(S_head);
				Font mFont = new Font("High Tower Text",Font.BOLD,30);
		        S_head.setFont(mFont);
		        
		        JLabel X_head;
				X_head = new JLabel("Amount");
				X_head.setBounds(490,180,200,20);
				fi.add(X_head);
				X_head.setFont(myFont);
		        JTextField tf1;
		        tf1=new JTextField();
		        tf1.setBounds(430,200,200,20);  
		        fi.add(tf1);
		        JLabel info = new JLabel();
					info = new JLabel("");
			        info.setBounds(320, 210,450,30);
					fi.add(info);
				
				String country[]={"INR","USD","KWD","EUR","GBP","JPY","IQD","XBT","AUD","IRR","ILS"};        
				JComboBox cb=new JComboBox(country);
		        cb.setBounds(600,145,200,20);  
		        fi.add(cb);
		        
		        JComboBox cb2=new JComboBox(country);
		        cb2.setBounds(280,145,200,20);  
		        fi.add(cb2);
		        
		        ImageIcon imageIcon = new ImageIcon("back.png");
				Image image = imageIcon.getImage();
				Image newimg = image.getScaledInstance(50, 50,  java.awt.Image.SCALE_SMOOTH);
				imageIcon = new ImageIcon(newimg);
		        JButton b_5=new JButton(imageIcon);
		        b_5.setBounds(30,50,100, 100);    
		        b_5.setBackground(Color.WHITE);
		        b_5.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_5);
		        
		        
				ImageIcon imageIcon_2 = new ImageIcon("cbutton.png");
				Image images = imageIcon_2.getImage();
				Image newimgs = images.getScaledInstance(140, 80,  java.awt.Image.SCALE_SMOOTH);
				imageIcon_2 = new ImageIcon(newimgs);
		        JButton b_6=new JButton(imageIcon_2);
		        b_6.setBounds(420, 226,220, 90);    
		        b_6.setBackground(Color.WHITE);
		        b_6.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_6);
				
		        
				
		        
		        b_6.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				    	
				    	JLabel h_head;
						h_head = new JLabel();
						h_head.setBounds(450,350,200,60);
						
					    fi.add(h_head);
				    	String curFrom = (String) cb2.getItemAt(cb2.getSelectedIndex());
					 	String curTo = (String) cb.getItemAt(cb.getSelectedIndex());
					 	String amt = tf1.getText();
					 	url = "http://www.xe.com/currencyconverter/convert/?Amount="+amt+"&From="+curFrom+"&To="+curTo;
					 	try {
							document = Jsoup.connect(url).get();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					 	Elements c_info = document.select(".uccAmountWrap span.uccResultAmount");
					 	Element firstParagraph_C = c_info.first();
					    p=firstParagraph_C;
					    Font xyFont = new Font("Microsoft Sans Serif",Font.BOLD,27);
					    h_head.setFont(xyFont);
					    h_head.setText(p.text()+" "+curTo);
				    }
				});
		        
				fi.setSize(1000,500);
				fi.addWindowListener(wl);
				fi.setResizable(false);
				
				b_5.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				        setVisible(true);
				        fi.setVisible(false);
				    }
				});
		    }
		});
		
		b_1.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent event) {
		        setVisible(false);
		        Frame fi = new Frame();
				fi.setLayout(null);
				fi.setVisible(true);
				JLabel S_head;
				S_head = new JLabel("WEATHER");
				S_head.setBounds(440, 75, 150, 50);
				fi.add(S_head);
				Font myFont = new Font("High Tower Text",Font.BOLD,20);
		        S_head.setFont(myFont);
		        JTextField tf1;
		        tf1=new JTextField();
		        tf1.setBounds(320,150,200,20);  
		        fi.add(tf1);
		        ImageIcon imageIcon = new ImageIcon("back.png");
				Image image = imageIcon.getImage();
				Image newimg = image.getScaledInstance(50, 50,  java.awt.Image.SCALE_SMOOTH);
				imageIcon = new ImageIcon(newimg);
		        JButton b_5=new JButton(imageIcon);
		        b_5.setBounds(30,50,100, 100);    
		        b_5.setBackground(Color.WHITE);
		        b_5.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_5);
		        
		        
				ImageIcon imageIcon_2 = new ImageIcon("search.png");
				Image images = imageIcon_2.getImage();
				Image newimgs = images.getScaledInstance(130, 25,  java.awt.Image.SCALE_SMOOTH);
				imageIcon_2 = new ImageIcon(newimgs);
		        JButton b_6=new JButton(imageIcon_2);
		        b_6.setBounds(530, 123,200, 70);    
		        b_6.setBackground(Color.WHITE);
		        b_6.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_6);
				
		        b_6.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
					 	String city = tf1.getText();
					 	url = "https://www.timeanddate.com/weather/india/"+city;
					 	try {
							document = Jsoup.connect(url).get();
						} catch (IOException e) {
							e.printStackTrace();
						}
					 	Elements w_info = document.select(".three div.h2");
					 	Element firstParagraph_w = w_info.first();
					 	Elements info_1 = document.select(".three p");
					 	Element f = info_1.first();
					 	Element l = info_1.last();
					 	p=firstParagraph_w;
					 	p=firstParagraph_w;
				        JLabel info = new JLabel();
						info = new JLabel("");
				        info.setBounds(220, 210,450,50);
						fi.add(info);
						JLabel info_x = new JLabel();
						info_x = new JLabel("");
				        info_x.setBounds(220, 270,650,50);
				        JLabel info_y = new JLabel();
						info_y = new JLabel("");
				        info_y.setBounds(220, 330,450,50);
				        fi.add(info_x);
				        fi.add(info_y);
						Font yFont = new Font("Microsoft Sans Serif",Font.BOLD,20);
				        info.setFont(yFont);
					    info.setText(p.text());
					 	Element q = l;
					 	info_x.setFont(yFont);
					 	info_x.setText(q.text());
					 	q = f;
					 	info_y.setFont(yFont);
					 	info_y.setText(q.text());
				    }
				});
		        
				fi.setSize(1000,500);
				fi.addWindowListener(wl);
				fi.setResizable(false);
				
				b_5.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				        setVisible(true);
				        fi.setVisible(false);
				    }
				});
		    }
		});
		
		b_4.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent event) {
		        setVisible(false);
		        Frame fi = new Frame();
				fi.setLayout(null);
				fi.setVisible(true);
				
				JLabel S_head;
				S_head = new JLabel("SHORT INFO");
				S_head.setBounds(440, 75, 150, 50);
				fi.add(S_head);
				Font myFont = new Font("High Tower Text",Font.BOLD,20);
		        S_head.setFont(myFont);
		        JLabel info[] = new JLabel[5];
				int x=210;
				fi.setBackground(Color.WHITE);
				for(int j=0;j<5;++j)
				{
					info[j] = new JLabel("");
			        info[j].setBounds(320, x,450,30);
			        x+=40;
					fi.add(info[j]);
				}
		        JTextField tf1;
		        tf1=new JTextField();
		        tf1.setBounds(320,150,200,20);  
		        fi.add(tf1);
		        ImageIcon imageIcon = new ImageIcon("back.png");
				Image image = imageIcon.getImage();
				Image newimg = image.getScaledInstance(50, 50,  java.awt.Image.SCALE_SMOOTH);
				imageIcon = new ImageIcon(newimg);
		        JButton b_5=new JButton(imageIcon);
		        b_5.setBounds(30,50,100, 100);    
		        b_5.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_5);
		        
		        
				ImageIcon imageIcon_2 = new ImageIcon("search.png");
				Image images = imageIcon_2.getImage();
				Image newimgs = images.getScaledInstance(130, 25,  java.awt.Image.SCALE_SMOOTH);
				imageIcon_2 = new ImageIcon(newimgs);
		        JButton b_6=new JButton(imageIcon_2);
		        b_6.setBounds(530, 123,200, 70);    
		        b_6.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_6);
				
		        b_6.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				    	
				    	System.out.println("\t\tNEWS\n\n");
					 	url = "https://www.inshorts.com/en/read/";
					 	try {
							document = Jsoup.connect(url).get();
						} catch (IOException e) {
							e.printStackTrace();
						}
					 	Elements n_info = document.select("a.clickable");
					 	Element f_n_news = n_info.first();
					 	Element l_n_news = n_info.last();
					 	p= f_n_news;
					 	String news[] = new String[5];
					 	int i=0;
					 	while (p!=l_n_news){
					        p=n_info.get(i);
					        news[i]=(i+1)+". "+p.text()+".";
					        info[i].setText(news[i]);
					        i++;
					        
					        if(i==5)
					        	break;
					    }
				    }
				});
		        
				fi.setSize(1000,500);
				fi.addWindowListener(wl);
				fi.setResizable(false);
				
				b_5.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				        setVisible(true);
				        fi.setVisible(false);
				    }
				});
		    }
		});
		
		b.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent event) {
		        setVisible(false);
		        Frame fi = new Frame();
				fi.setLayout(null);
				fi.setVisible(true);
				JLabel S_head;
				S_head = new JLabel("NEWS");
				S_head.setBounds(440, 75, 150, 50);
				fi.add(S_head);
				Font myFont = new Font("High Tower Text",Font.BOLD,20);
		        S_head.setFont(myFont);
		        JLabel info[] = new JLabel[5];
				int x=210;
				for(int j=0;j<5;++j)
				{
					info[j] = new JLabel("");
			        info[j].setBounds(320, x,450,30);
			        x+=40;
					fi.add(info[j]);
				}
		        ImageIcon imageIcon = new ImageIcon("back.png");
				Image image = imageIcon.getImage();
				Image newimg = image.getScaledInstance(50, 50,  java.awt.Image.SCALE_SMOOTH);
				imageIcon = new ImageIcon(newimg);
		        JButton b_5=new JButton(imageIcon);
		        b_5.setBounds(30,50,100, 100);    
		        b_5.setBackground(Color.WHITE);
		        b_5.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
		        fi.add(b_5);
		    	
				    	System.out.println("\t\tNEWS\n\n");
					 	url = "https://www.inshorts.com/en/read/";
					 	try {
							document = Jsoup.connect(url).get();
						} catch (IOException e) {
							e.printStackTrace();
						}
					 	Elements n_info = document.select("a.clickable");
					 	Element f_n_news = n_info.first();
					 	Element l_n_news = n_info.last();
					 	p= f_n_news;
					 	String news[] = new String[5];
					 	int i=0;
					 	while (p!=l_n_news){
					        p=n_info.get(i);
					        news[i]=(i+1)+". "+p.text()+".";
					        info[i].setText(news[i]);
					        i++;
					        
					        if(i==5)
					        	break;
					    }
		        
				fi.setSize(1000,500);
				fi.addWindowListener(wl);
				fi.setResizable(false);
				
				b_5.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent event) {
				        setVisible(true);
				        fi.setVisible(false);
				    }
				});
		    }
		});
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
	}
	public static void main(String []args) throws Exception 
	{
		new PDA();
	}

}
